"""Command-line interface for the Ashh66 hash checker."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from .hasher import ALGORITHMS, compare_digest, hash_bytes, hash_file


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="hash-checker",
        description=(
            "Hash local files or text and optionally compare a known digest. "
            "Use only on files you own or are allowed to inspect."
        ),
    )
    parser.add_argument(
        "paths",
        nargs="*",
        help="Files to hash",
    )
    parser.add_argument(
        "--text",
        help="Hash this string instead of a file",
    )
    parser.add_argument(
        "-a",
        "--algo",
        default="sha256",
        choices=ALGORITHMS,
        help="Digest algorithm (default: sha256)",
    )
    parser.add_argument(
        "--expect",
        help="Known digest to compare (single file or --text only)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="Print machine-readable JSON",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    if args.text is not None and args.paths:
        print("error: use files or --text, not both", file=sys.stderr)
        return 2
    if args.text is None and not args.paths:
        print("error: provide a file path or --text", file=sys.stderr)
        return 2
    if args.expect and len(args.paths) > 1:
        print("error: --expect works with one file or --text", file=sys.stderr)
        return 2

    started = datetime.now(timezone.utc)
    records: list[dict[str, object]] = []
    exit_code = 0

    try:
        if args.text is not None:
            digest = hash_bytes(args.text.encode("utf-8"), args.algo)
            record: dict[str, object] = {
                "source": "text",
                "algorithm": args.algo,
                "digest": digest,
            }
            if args.expect:
                matched = compare_digest(digest, args.expect)
                record["expected"] = args.expect
                record["verdict"] = "match" if matched else "mismatch"
                if not matched:
                    exit_code = 1
            else:
                record["verdict"] = "hashed"
            records.append(record)
        else:
            for raw_path in args.paths:
                path = Path(raw_path)
                digest = hash_file(path, args.algo)
                record = {
                    "source": str(path),
                    "algorithm": args.algo,
                    "digest": digest,
                }
                if args.expect:
                    matched = compare_digest(digest, args.expect)
                    record["expected"] = args.expect
                    record["verdict"] = "match" if matched else "mismatch"
                    if not matched:
                        exit_code = 1
                else:
                    record["verdict"] = "hashed"
                records.append(record)
    except OSError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    finished = datetime.now(timezone.utc)
    payload = {
        "operator": "Ashh66",
        "started_utc": started.isoformat(),
        "finished_utc": finished.isoformat(),
        "count": len(records),
        "results": records,
    }

    if args.as_json:
        print(json.dumps(payload, indent=2))
        return exit_code

    print("Ashh66 hash checker")
    print(f"algo     {args.algo}")
    print(f"window   {started.strftime('%H:%M:%S')}Z -> {finished.strftime('%H:%M:%S')}Z")
    print()
    print(f"{'VERDICT':<12}{'DIGEST':<68}SOURCE")
    for record in records:
        print(f"{record['verdict']:<12}{record['digest']:<68}{record['source']}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
