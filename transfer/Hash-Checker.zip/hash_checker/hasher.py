"""Hash files and compare digests."""

from __future__ import annotations

import hashlib
from pathlib import Path

ALGORITHMS = ("md5", "sha1", "sha256", "sha512")
CHUNK_SIZE = 1024 * 1024


def normalize_digest(value: str) -> str:
    text = value.strip().lower()
    if text.startswith("0x"):
        text = text[2:]
    return text


def hash_bytes(data: bytes, algorithm: str = "sha256") -> str:
    if algorithm not in ALGORITHMS:
        raise ValueError(f"unsupported algorithm: {algorithm}")
    digest = hashlib.new(algorithm)
    digest.update(data)
    return digest.hexdigest()


def hash_file(path: Path, algorithm: str = "sha256") -> str:
    if algorithm not in ALGORITHMS:
        raise ValueError(f"unsupported algorithm: {algorithm}")
    digest = hashlib.new(algorithm)
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(CHUNK_SIZE)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def compare_digest(actual: str, expected: str) -> bool:
    return normalize_digest(actual) == normalize_digest(expected)
