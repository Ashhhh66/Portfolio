# Hash Checker

File and text digest tool by **Ashh66**.

Hash local files you own or are allowed to inspect. This is an integrity helper, not a malware scanner.

## What it does

- SHA-256 by default (also md5, sha1, sha512)
- Hashes files in chunks
- Hashes a `--text` string
- Compares a known digest with `--expect`
- Text table or JSON output
- Exit code `1` on mismatch

## Requirements

Python 3.9+ and the standard library. No pip packages.

## Usage

```bash
python3 hash.py README.md
python3 hash.py README.md --expect  <known-sha256>
python3 hash.py --text "ashh66" --json
python3 hash.py note.txt --algo sha1
python3 -m hash_checker README.md
```

| Flag | Meaning |
| --- | --- |
| `-a`, `--algo` | `md5`, `sha1`, `sha256`, `sha512` |
| `--text` | Hash a string instead of a file |
| `--expect` | Known digest to compare |
| `--json` | Machine-readable output |

`md5` and `sha1` are for looking up older hashes. Prefer `sha256` for new checks.

## Tests

```bash
PYTHONPATH=. python3 -m unittest discover -s tests -v
```

## Authorized use

Only hash files you control or have permission to inspect.
