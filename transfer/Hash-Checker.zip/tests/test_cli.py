import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from hash_checker.cli import main
from hash_checker.hasher import hash_bytes


class CliTests(unittest.TestCase):
    def test_text_json(self) -> None:
        stdout = io.StringIO()
        with patch("sys.stdout", stdout):
            code = main(["--text", "ashh66", "--json"])
        self.assertEqual(code, 0)
        self.assertIn(hash_bytes(b"ashh66", "sha256"), stdout.getvalue())

    def test_expect_match_and_mismatch(self) -> None:
        digest = hash_bytes(b"ok", "sha256")
        self.assertEqual(main(["--text", "ok", "--expect", digest]), 0)
        self.assertEqual(main(["--text", "ok", "--expect", "00" * 32]), 1)

    def test_file_hash(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "note.txt"
            path.write_text("desk", encoding="utf-8")
            stdout = io.StringIO()
            with patch("sys.stdout", stdout):
                code = main([str(path), "--json"])
            self.assertEqual(code, 0)
            self.assertIn("hashed", stdout.getvalue())

    def test_rejects_mixed_inputs(self) -> None:
        stderr = io.StringIO()
        with patch("sys.stderr", stderr):
            code = main(["file.bin", "--text", "nope"])
        self.assertEqual(code, 2)
        self.assertIn("not both", stderr.getvalue())


if __name__ == "__main__":
    unittest.main()
