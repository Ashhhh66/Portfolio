import hashlib
import tempfile
import unittest
from pathlib import Path

from hash_checker.hasher import compare_digest, hash_bytes, hash_file


class HasherTests(unittest.TestCase):
    def test_hash_bytes_sha256(self) -> None:
        self.assertEqual(
            hash_bytes(b"ashh66", "sha256"),
            hashlib.sha256(b"ashh66").hexdigest(),
        )

    def test_hash_file_matches_bytes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sample.bin"
            path.write_bytes(b"watch-desk")
            self.assertEqual(hash_file(path, "sha256"), hash_bytes(b"watch-desk", "sha256"))

    def test_compare_digest_ignores_case_and_prefix(self) -> None:
        digest = hash_bytes(b"x", "sha256")
        self.assertTrue(compare_digest(digest, "0x" + digest.upper()))
        self.assertFalse(compare_digest(digest, "deadbeef"))

    def test_rejects_unknown_algorithm(self) -> None:
        with self.assertRaises(ValueError):
            hash_bytes(b"x", "blake2s")


if __name__ == "__main__":
    unittest.main()
