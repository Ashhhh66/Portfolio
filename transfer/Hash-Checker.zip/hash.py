#!/usr/bin/env python3
from hash_checker.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
