# Port Scanner

TCP connect scanner by **Ashh66**.

Scan hosts you own or have permission to test. This is a lab/admin tool, not a stealth scanner and not an exploit kit.

## What it does

- Resolves a hostname or IP
- Probes TCP ports with `connect()` (no raw sockets, no root)
- Runs probes concurrently
- Labels well-known services
- Optional short banner read
- Text table or JSON output

## Requirements

Python 3.9+ and the standard library. No pip packages.

## Usage

```bash
python3 scan.py 127.0.0.1 --common --open-only
python3 scan.py 127.0.0.1 -p 22,80,443
python3 scan.py example.com -p 1-1024 -w 300 --banner
python3 -m port_scanner 127.0.0.1 --common --json
```

| Flag | Meaning |
| --- | --- |
| `-p`, `--ports` | Ports or ranges (`22,80,443` or `1-1024`) |
| `--common` | Built-in common TCP service list |
| `-t`, `--timeout` | Seconds to wait per connect |
| `-w`, `--workers` | Concurrent probes |
| `--banner` | Read a short banner from open ports |
| `--json` | Machine-readable output |
| `--open-only` | Hide closed/filtered ports in text mode |

## Tests

```bash
PYTHONPATH=. python3 -m unittest discover -s tests -v
```

## Authorized use

Only scan systems you control or have written permission to assess. Unauthorized scanning can be illegal.
