import io
import unittest
from unittest.mock import patch

from port_scanner.cli import main


class CliTests(unittest.TestCase):
    @patch("port_scanner.cli.scan_host")
    def test_common_overrides_ports_warning(self, mock_scan) -> None:
        mock_scan.return_value = ("127.0.0.1", "127.0.0.1", [])
        stderr = io.StringIO()
        with patch("sys.stderr", stderr):
            main(["127.0.0.1", "--common", "-p", "22"])
        self.assertIn("note: --common overrides -p/--ports", stderr.getvalue())
        mock_scan.assert_called_once()
        scanned_ports = list(mock_scan.call_args.args[1])
        self.assertNotEqual(scanned_ports, [22])
        self.assertIn(22, scanned_ports)
        self.assertIn(443, scanned_ports)

    @patch("port_scanner.cli.scan_host")
    def test_common_with_default_ports_is_quiet(self, mock_scan) -> None:
        mock_scan.return_value = ("127.0.0.1", "127.0.0.1", [])
        stderr = io.StringIO()
        with patch("sys.stderr", stderr):
            main(["127.0.0.1", "--common"])
        self.assertNotIn("overrides", stderr.getvalue())
