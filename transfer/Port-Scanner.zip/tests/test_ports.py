import unittest

from port_scanner.ports import parse_ports, service_name


class ParsePortsTests(unittest.TestCase):
    def test_single_port(self) -> None:
        self.assertEqual(parse_ports("22"), [22])

    def test_list_and_range(self) -> None:
        self.assertEqual(parse_ports("22,80-82,443"), [22, 80, 81, 82, 443])

    def test_rejects_out_of_range(self) -> None:
        with self.assertRaises(ValueError):
            parse_ports("0")
        with self.assertRaises(ValueError):
            parse_ports("1-70000")

    def test_service_name(self) -> None:
        self.assertEqual(service_name(22), "ssh")
        self.assertEqual(service_name(9), "unknown")


if __name__ == "__main__":
    unittest.main()
