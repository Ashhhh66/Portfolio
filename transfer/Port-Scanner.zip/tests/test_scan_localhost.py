import socket
import unittest

from port_scanner.scanner import scan_host


class LiveScanTests(unittest.TestCase):
    def test_detects_open_listener(self) -> None:
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind(("127.0.0.1", 0))
        listener.listen(1)
        open_port = listener.getsockname()[1]
        closed_port = 9 if open_port != 9 else 10
        try:
            _, address, results = scan_host(
                "127.0.0.1",
                [open_port, closed_port],
                timeout=0.4,
                workers=2,
            )
            self.assertEqual(address, "127.0.0.1")
            by_port = {item.port: item.state for item in results}
            self.assertEqual(by_port[open_port], "open")
            self.assertIn(by_port[closed_port], {"closed", "filtered"})
        finally:
            listener.close()


if __name__ == "__main__":
    unittest.main()
