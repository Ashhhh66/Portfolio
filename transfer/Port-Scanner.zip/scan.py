#!/usr/bin/env python3
from port_scanner.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
