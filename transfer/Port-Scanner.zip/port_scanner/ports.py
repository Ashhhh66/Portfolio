"""Port-range parsing and a short list of common TCP services."""

from __future__ import annotations

COMMON_TCP_PORTS = {
    20: "ftp-data",
    21: "ftp",
    22: "ssh",
    23: "telnet",
    25: "smtp",
    53: "dns",
    80: "http",
    110: "pop3",
    111: "rpcbind",
    135: "msrpc",
    139: "netbios-ssn",
    143: "imap",
    443: "https",
    445: "smb",
    465: "smtps",
    587: "submission",
    993: "imaps",
    995: "pop3s",
    1433: "mssql",
    1521: "oracle",
    2049: "nfs",
    3306: "mysql",
    3389: "rdp",
    5432: "postgres",
    5900: "vnc",
    6379: "redis",
    8080: "http-alt",
    8443: "https-alt",
    27017: "mongodb",
}


def parse_ports(spec: str) -> list[int]:
    """Parse a comma-separated list of ports and inclusive ranges.

    Examples: ``22``, ``22,80,443``, ``1-1024``, ``22,80-90,443``.
    """
    ports: set[int] = set()
    for chunk in spec.split(","):
        item = chunk.strip()
        if not item:
            raise ValueError("empty port entry")
        if "-" in item:
            start_text, end_text = item.split("-", 1)
            start, end = int(start_text), int(end_text)
            if start > end:
                start, end = end, start
            if start < 1 or end > 65535:
                raise ValueError(f"port range out of bounds: {item}")
            ports.update(range(start, end + 1))
        else:
            port = int(item)
            if port < 1 or port > 65535:
                raise ValueError(f"port out of bounds: {item}")
            ports.add(port)
    return sorted(ports)


def service_name(port: int) -> str:
    return COMMON_TCP_PORTS.get(port, "unknown")
