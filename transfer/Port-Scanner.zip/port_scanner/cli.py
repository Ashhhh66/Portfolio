"""Command-line interface for the Ashh66 TCP port scanner."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone

from .ports import COMMON_TCP_PORTS, parse_ports
from .scanner import scan_host


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="port-scanner",
        description=(
            "TCP connect port scanner. Scan only hosts you own or have "
            "permission to test."
        ),
    )
    parser.add_argument("target", help="Hostname or IPv4/IPv6 address")
    parser.add_argument(
        "-p",
        "--ports",
        default="1-1024",
        help="Ports or ranges, e.g. 22,80,443 or 1-1024 (default: 1-1024)",
    )
    parser.add_argument(
        "--common",
        action="store_true",
        help="Scan a built-in list of common TCP service ports",
    )
    parser.add_argument(
        "-t",
        "--timeout",
        type=float,
        default=0.8,
        help="Per-port timeout in seconds (default: 0.8)",
    )
    parser.add_argument(
        "-w",
        "--workers",
        type=int,
        default=200,
        help="Concurrent connect workers (default: 200)",
    )
    parser.add_argument(
        "--banner",
        action="store_true",
        help="Read a short banner from open ports when one is offered",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="Print machine-readable JSON",
    )
    parser.add_argument(
        "--open-only",
        action="store_true",
        help="Hide closed and filtered ports in text output",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    try:
        ports = sorted(COMMON_TCP_PORTS) if args.common else parse_ports(args.ports)
    except ValueError as exc:
        print(f"error: invalid ports: {exc}", file=sys.stderr)
        return 2

    started = datetime.now(timezone.utc)
    try:
        target, address, results = scan_host(
            args.target,
            ports,
            timeout=args.timeout,
            workers=args.workers,
            grab_banner=args.banner,
        )
    except OSError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    finished = datetime.now(timezone.utc)
    open_ports = [item for item in results if item.state == "open"]

    payload = {
        "operator": "Ashh66",
        "target": target,
        "address": address,
        "started_utc": started.isoformat(),
        "finished_utc": finished.isoformat(),
        "ports_scanned": len(results),
        "open_count": len(open_ports),
        "results": [item.to_dict() for item in results],
    }

    if args.as_json:
        print(json.dumps(payload, indent=2))
        return 0

    print(f"Ashh66 port scanner")
    print(f"target   {target} ({address})")
    print(f"scanned  {len(results)} tcp ports")
    print(f"open     {len(open_ports)}")
    print(f"window   {started.strftime('%H:%M:%S')}Z -> {finished.strftime('%H:%M:%S')}Z")
    print()
    print(f"{'PORT':<10}{'STATE':<12}{'SERVICE':<14}BANNER")
    visible = open_ports if args.open_only else results
    if args.open_only and not visible:
        print("(no open ports)")
        return 0
    for item in visible:
        banner = item.banner or ""
        print(f"{item.port:<10}{item.state:<12}{item.service:<14}{banner}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
