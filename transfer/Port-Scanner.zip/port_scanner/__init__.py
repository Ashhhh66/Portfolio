"""Ashh66 TCP connect port scanner."""

from .ports import COMMON_TCP_PORTS, parse_ports, service_name
from .scanner import PortResult, scan_host

__all__ = [
    "COMMON_TCP_PORTS",
    "PortResult",
    "parse_ports",
    "scan_host",
    "service_name",
]
__version__ = "1.0.0"
