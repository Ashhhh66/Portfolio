"""Concurrent TCP connect scanner."""

from __future__ import annotations

import socket
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from typing import Iterable

from .ports import service_name


@dataclass(frozen=True)
class PortResult:
    port: int
    state: str
    service: str
    banner: str | None = None

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def resolve_target(target: str) -> str:
    try:
        infos = socket.getaddrinfo(
            target, None, family=socket.AF_INET, type=socket.SOCK_STREAM
        )
    except socket.gaierror:
        infos = socket.getaddrinfo(target, None, type=socket.SOCK_STREAM)
    if not infos:
        raise socket.gaierror(f"could not resolve {target}")
    return infos[0][4][0]


def _probe(
    host: str,
    port: int,
    timeout: float,
    grab_banner: bool,
) -> PortResult:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        result = sock.connect_ex((host, port))
        if result != 0:
            return PortResult(port=port, state="closed", service=service_name(port))

        banner = None
        if grab_banner:
            try:
                banner_bytes = sock.recv(128)
                if banner_bytes:
                    banner = banner_bytes.decode("utf-8", errors="replace").strip()
            except OSError:
                banner = None
        return PortResult(
            port=port,
            state="open",
            service=service_name(port),
            banner=banner or None,
        )
    except socket.timeout:
        return PortResult(port=port, state="filtered", service=service_name(port))
    except ConnectionRefusedError:
        return PortResult(port=port, state="closed", service=service_name(port))
    except OSError:
        return PortResult(port=port, state="error", service=service_name(port))
    finally:
        sock.close()


def scan_host(
    target: str,
    ports: Iterable[int],
    timeout: float = 0.8,
    workers: int = 200,
    grab_banner: bool = False,
) -> tuple[str, str, list[PortResult]]:
    """Scan TCP ports on a single host using connect() probes.

    Returns the original target, resolved address, and per-port results.
    """
    address = resolve_target(target)
    port_list = list(ports)
    results: list[PortResult] = []

    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        futures = [
            pool.submit(_probe, address, port, timeout, grab_banner) for port in port_list
        ]
        for future in as_completed(futures):
            results.append(future.result())

    results.sort(key=lambda item: item.port)
    return target, address, results
